from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs
import os
import random

# Dictionary to store usernames and passwords
user_credentials = {
    'admin': 'password123',
    'user1': 'pass456',
    'user2': 'abc123'
}

# HTTP Request Handler
class RequestHandler(BaseHTTPRequestHandler):
    # Handle GET requests
    def do_GET(self):
        if self.path == '/':
            # Set the response status code
            self.send_response(200)

            # Set the response headers
            self.send_header('Content-type', 'text/html')
            self.end_headers()

            # Set the response content
            with open(r'e:\VS work\Web Work\login form\login.html', 'rb') as file:
                response_content = file.read()
                self.wfile.write(response_content)

        elif self.path == '/style.css':
                self.send_response(200)
                self.send_header('Content-type', 'text/css')
                self.end_headers()

                # Get the absolute file path of style.css
                script_dir = os.path.dirname(os.path.abspath(__file__))
                file_path = os.path.join(os.path.dirname(__file__), 'style.css')

                with open(file_path, 'rb') as file:
                    response_content = file.read()
                    self.wfile.write(response_content)

        elif self.path == '/logo.png':
            self.send_response(200)
            self.send_header('Content-type', 'image/png')
            self.end_headers()

            # Get the absolute file path of logo.png
            script_dir = os.path.dirname(os.path.abspath(__file__))
            file_path = os.path.join(os.path.dirname(__file__), 'logo.png')

            # Read the logo.png file
            with open(file_path, 'rb') as file:
                response_content = file.read()
                self.wfile.write(response_content)
        
        else:
            self.send_response(404)
            self.end_headers()

    # Handle POST requests
    def do_POST(self):
        if self.path == '/login':
            # Set the response status code
            self.send_response(200)

            # Set the response headers
            self.send_header('Content-type', 'text/html')
            self.end_headers()

            # Get the form data
            content_length = int(self.headers['Content-Length'])
            form_data = self.rfile.read(content_length).decode()
            form_values = parse_qs(form_data)

            # Extract the username and password from the form data
            username = form_values.get('username', [''])[0]
            password = form_values.get('password', [''])[0]

            # Validate the username and password
            if username == 'admin' and password == 'password':
                response_content = response_content = """
                        <html>
                            <head>
                                <title>About Me</title>
                                <style>
                                    /* Reset some default styles */
                                    html, body, h1, h2, h3, p, ul, li {
                                    margin: 0;
                                    padding: 0;
                                    }
                                    h4{
                                        color: green;
                                        text-align: center;
                                    }
                                    body {
                                    font-family: Arial, sans-serif;
                                    line-height: 1.5;
                                    }
                                    header {
                                    background-color: #333;
                                    color: #fff;
                                    padding: 20px;
                                    }
                                    header h1 {
                                    font-size: 24px;
                                    margin-bottom: 10px;
                                    }
                                    nav ul {
                                    list-style-type: none;
                                    }
                                    nav ul li {
                                    display: inline-block;
                                    margin-right: 10px;
                                    }
                                    nav ul li a {
                                    color: #fff;
                                    text-decoration: none;
                                    }
                                    main {
                                    padding: 20px;
                                    }
                                    section {
                                    margin-bottom: 30px;
                                    }
                                    section h2 {
                                    font-size: 20px;
                                    margin-bottom: 10px;
                                    }
                                    section p {
                                    margin-bottom: 10px;
                                    }
                                    section ul {
                                    list-style-type: disc;
                                    margin-left: 20px;
                                    }
                                    footer {
                                    background-color: #333;
                                    color: #fff;
                                    padding: 10px;
                                    text-align: center;
                                    }
                                    footer p {
                                    font-size: 14px;
                                    }
                                    /* Colorful styles */
                                    header {
                                        background-color: #4287f5;
                                    }
                                    header h1 {
                                        color: #fff;
                                        text-align: center;
                                    }
                                    nav ul li a {
                                        color: #fff;
                                        text-decoration: none;
                                        padding: 5px 10px;
                                        background-color: #4287f5;
                                        border-radius: 3px;
                                    }
                                    nav ul li a:hover {
                                        background-color: #366ec9;
                                    }
                                    section h2 {
                                        color: #4287f5;
                                    }
                                    section p {
                                        color: #555;
                                    }
                                    section ul {
                                        olor: #555;
                                    }
                                    footer {
                                        background-color: #4287f5;
                                    }
                                    footer p {
                                        color: #fff;
                                    }
                                    /* Responsive styles for smaller screens */
                                    @media (max-width: 600px) {
                                    header h1 {
                                        font-size: 20px;
                                    }
                                    nav ul li {
                                        display: block;
                                        margin-bottom: 5px;
                                    }
                                    main {
                                        padding: 10px;
                                    }
                                    section h2 {
                                        font-size: 18px;
                                    }
                                    footer p {
                                        font-size: 12px;
                                    }
                                </style>
                            </head>
                            <body>
                                <h4>Successfully Login</h4>
                                <header>
                                    <h1>About Me</h1>
                                    <nav>
                                    <ul>
                                        <li><a href="#overview">Overview</a></li>
                                        <li><a href="#education">Education</a></li>
                                        <li><a href="#skills">Skills</a></li>
                                        <li><a href="#projects">Projects</a></li>
                                    </ul>
                                    </nav>
                                </header>
                                <main>
                                    <section id="overview">
                                    <h2>Overview</h2>
                                    <p>Welcome to my About Me page! I'm a passionate web developer with experience in HTML, CSS, and JavaScript.</p>
                                    </section>
                                    <section id="education">
                                    <h2>Education</h2>
                                    <ul>
                                        <li>
                                        <h3>University of Engineering and Technology Taxila</h3>
                                        <p>Bachelor's degree in Telecomunication. Specialized in front-end development and UX design.</p>
                                        </li>
                                        <li>
                                        <h3>Online Courses</h3>
                                        <p>Continuously expanding my knowledge through online courses in various web technologies and programming languages.</p>
                                        </li>
                                    </ul>
                                    </section>
                                    <section id="skills">
                                    <h2>Skills</h2>
                                    <ul>
                                        <li>HTML5</li>
                                        <li>CSS3</li>
                                        <li>JavaScript</li>
                                        <li>React</li>
                                        <li>Responsive Web Design</li>
                                        <li>UX/UI Design</li>
                                        <li>Python</li>
                                    </ul>
                                    </section>
                                    <section id="projects">
                                    <h2>Projects</h2>
                                    <ul>
                                        <li>
                                        <h3>Portfolio Website</h3>
                                        <p>Developed a personal portfolio website to showcase my work and skills.</p>
                                        </li>
                                        <li>
                                        <h3>E-commerce Website</h3>
                                        <p>Collaborated on building an e-commerce website with a focus on user experience and responsive design.</p>
                                        </li>
                                        <li>
                                        <h3>Weather App</h3>
                                        <p>Created a weather application that displays current weather information using a third-party API.</p>
                                        </li>
                                    </ul>
                                    </section>
                                </main>
                        <footer>
                            <p>&copy; 2023 My Website. All rights reserved.</p>
                        </footer>
                        </body>
                    </html>
                """
            else:
                response_content = """
                    <html>
                        <head>
                            <style>
                                h1{
                                    color: red;
                                    font-size:50px;
                                    text-align:center;
                                    padding:20px;
                                }
                            </style>
                        </head>
                        <body>
                            <h1>Invalid username or password!</h1>
                        </body>
                    </html>
                """

            self.wfile.write(response_content.encode())
        else:
            self.send_response(404)
            self.end_headers()

# Server Configuration
host = 'localhost'
port = 8000

# Start the HTTP server
server = HTTPServer((host, port), RequestHandler)
print(f"Server running on {host}:{port}")

try:
    # Listen for requests indefinitely
    server.serve_forever()
except KeyboardInterrupt:
    # Handle keyboard interrupt (Ctrl+C)
    print("\nServer interrupted. Shutting down.")
    server.server_close()
